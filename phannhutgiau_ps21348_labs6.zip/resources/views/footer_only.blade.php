
@foreach ($category as $categorys)
    {{$categorys}}
@endforeach